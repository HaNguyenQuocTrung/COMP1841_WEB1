<p class="total-posts"><?= $totalposts ?> Questions have been submitted to the Greenwich Trung hahaha.</p>

<div class="posts-container">
    <?php foreach ($posts as $post): ?>
        <blockquote class="post">
            <p class="post-text"><?= htmlspecialchars($post['posttext'], ENT_QUOTES, 'UTF-8') ?></p>

            <div class="post-meta">
                <span class="module">module: <?= htmlspecialchars($post['moduleName'], ENT_QUOTES, 'UTF-8') ?></span> |
                <span class="user">by <?= htmlspecialchars($post['name'], ENT_QUOTES, 'UTF-8'); ?></span> |
                <span class="date">Posted: <?= htmlspecialchars(date("D d M Y", strtotime($post['postdate'])), ENT_QUOTES, 'UTF-8') ?></span>

                <?php if (isset($post['edited_by_admin']) && $post['edited_by_admin'] == 1): ?>
                    <span class="edit-info">(Edited by admin on <?= htmlspecialchars(date("D d M Y, g:i a", strtotime($post['edit_date'])), ENT_QUOTES, 'UTF-8') ?>)</span>
                <?php endif; ?>
            </div>

            <?php if (isset($post['image']) && $post['image']): ?>
                <img class="post-image" src="../image/<?= htmlspecialchars($post['image'], ENT_QUOTES, 'UTF-8'); ?>" alt="post image" />
            <?php endif; ?>

            <div class="post-actions">
                <a href="editpost.php?id=<?= $post['id'] ?>" class="edit-button">Edit</a>
                <form action="deletepost.php" method="post" class="delete-form">
                    <input type="hidden" name="id" value="<?= $post['id'] ?>">
                    <input type="submit" value="Delete" class="delete-button">
                </form>
            </div>
        </blockquote>
    <?php endforeach; ?>
</div>