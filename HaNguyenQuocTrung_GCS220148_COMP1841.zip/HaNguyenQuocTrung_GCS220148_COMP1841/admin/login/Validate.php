<?php
$ActualPassword = "secret";
if ($_POST["password"] == $ActualPassword) {
    session_start();
    $_SESSION["userised"] = "Y";
    header("Location:../posts.php");
} else {
    header("Location:Wrongpassword.php");
}
