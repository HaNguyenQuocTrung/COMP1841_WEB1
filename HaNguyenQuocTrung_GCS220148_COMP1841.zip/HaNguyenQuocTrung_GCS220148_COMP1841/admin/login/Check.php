<?php
session_start();
if ($_SESSION["userised"] != "Y") {
    header("Location: Notuserised.php");
}
