<?php
if (isset($_POST['message'])) {
    $title= "contact us";
    $message = $_POST['message'];
    ini_set("SMTP", "smtp.gre.ac.uk");
    ini_set("sendmail_form", "you@gre.ac.uk");
    mail("you@gre.ac.uk", "the subject - testing email connection", $message);
    $output = "Thank you for your message we will get back to you shortly ";
} else{   
    $title = "contact us";
    include 'templates/mail_form.html.php';
    $output = ob_get_clean();
}
include 'templates/layout.html.php';