<?php
include 'includes/DatabaseConnection.php';

function query($pdo, $sql, $parameters = [])
{
    $query = $pdo->prepare($sql);
    $query->execute($parameters);
    return $query;
}

function totalposts($pdo)
{
    $query = $pdo->prepare('SELECT COUNT(*) FROM post');
    $query->execute();
    $row = $query->fetch();
    return $row[0];
}

function getpost($pdo, $id)
{
    $parameters = [':id' => $id];
    $query = query($pdo, 'SELECT post.*, user.name, post.edit_date, module.moduleName 
            FROM post 
            LEFT JOIN user ON post.userid = user.id 
            LEFT JOIN module ON post.moduleid = module.id
            WHERE post.id = :id', $parameters);
    return $query->fetch();
}

function updatepost($pdo, $postId, $posttext, $userid = null, $moduleid = null, $image = null, $is_admin = false)
{
    $query = 'UPDATE post SET posttext = :posttext';
    $parameters = [':posttext' => $posttext, ':id' => $postId];

    if ($userid !== null) {
        $query .= ', userid = :userid';
        $parameters[':userid'] = $userid;
    }

    if ($moduleid !== null) {
        $query .= ', moduleid = :moduleid';
        $parameters[':moduleid'] = $moduleid;
    }

    // Always update image field with the provided image value
    $query .= ', image = :image';
    $parameters[':image'] = $image;

    // Only set edited_by_admin and edit_date if it's an admin edit
    if ($is_admin) {
        $query .= ', edited_by_admin = 1, edit_date = NOW()';
    }

    $query .= ' WHERE id = :id';
    query($pdo, $query, $parameters);
}

function deletepost($pdo, $id)
{
    $parameters = [':id' => $id];
    query($pdo, 'DELETE FROM post WHERE id = :id', $parameters);
}

function insertpost($pdo, $posttext, $fileToUpload, $userid, $moduleid)
{
    $query = 'INSERT INTO post (posttext, postdate, `image`, userid, moduleid)
    VALUE (:posttext, CURDATE(), :fileToUpload, :userid, :moduleid)';
    $parameters = [':posttext' => $posttext, ':fileToUpload' => $fileToUpload, ':userid' => $userid, ':moduleid' => $moduleid];
    query($pdo, $query, $parameters);
}

function allusers($pdo)
{
    $users = query($pdo, 'SELECT * FROM user');
    return $users->fetchAll();
}

function allmodulen($pdo)
{
    $modulen = query($pdo, 'SELECT * FROM module');
    return $modulen->fetchAll();
}

function allposts($pdo)
{
    $posts = query($pdo, 'SELECT post.id, post.posttext, post.postdate, post.image,
        user.name, module.moduleName, post.edited_by_admin, post.edit_date 
        FROM post 
        INNER JOIN user ON post.userid = user.id
        INNER JOIN module ON post.moduleid = module.id');
    return $posts->fetchAll();
}

function getAllFeedback($pdo) {
    $query = 'SELECT user_message.*, user.name 
              FROM user_message 
              LEFT JOIN user ON user_message.user_id = user.id 
              ORDER BY time DESC';
    $feedback = query($pdo, $query);
    return $feedback->fetchAll();
}