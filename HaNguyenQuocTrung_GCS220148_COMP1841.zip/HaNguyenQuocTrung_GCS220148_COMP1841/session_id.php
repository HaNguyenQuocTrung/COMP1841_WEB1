<?php 
session_start();
$test = session_id();
echo "This session id is<br />" . $test;
?>