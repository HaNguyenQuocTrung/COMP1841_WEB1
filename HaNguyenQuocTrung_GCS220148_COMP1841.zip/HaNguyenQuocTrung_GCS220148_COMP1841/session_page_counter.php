<?php session_start();

if (empty($_SESSION["count"])) {
    $_SESSION["count"] = 1;
} else {
    $_SESSION["count"]++;
}
$sessionId = session_id();
echo "Hello visitor, you have seen this page" . $_SESSION['count'] . " times."; ?>