CREATE DATABASE CourseWork;

CREATE TABLE post (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    posttext TEXT COLLATE utf8_general_ci NOT NULL,
    postdate DATE DEFAULT NULL,
    image VARCHAR(255) COLLATE utf8_general_ci NOT NULL,
    userid INT(11) DEFAULT NULL,
    moduleid INT(11) DEFAULT NULL,
    edited_by_admin TINYINT(1) DEFAULT 0,
    edit_date DATETIME DEFAULT NULL
);

CREATE TABLE module (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    moduleName VARCHAR(255) COLLATE utf8_general_ci DEFAULT NULL
);

CREATE TABLE user (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) COLLATE utf8_general_ci DEFAULT NULL,
    email VARCHAR(255) COLLATE utf8_general_ci DEFAULT NULL UNIQUE,
    password VARCHAR(512) COLLATE utf8_general_ci NOT NULL
);

CREATE TABLE postmodule (
    postid INT(11) NOT NULL,
    moduleid INT(11) NOT NULL,
    PRIMARY KEY (postid, moduleid)
);

CREATE TABLE user_message (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    feedback_message TEXT NOT NULL,
    email VARCHAR(255) NOT NULL,
    time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    user_id INT(11) NOT NULL
);