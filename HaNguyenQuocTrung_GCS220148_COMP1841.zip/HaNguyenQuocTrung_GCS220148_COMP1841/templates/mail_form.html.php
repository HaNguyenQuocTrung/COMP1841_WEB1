<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>mail form</title>
</head>
<body>
<form action="send.php" method="post">
    <textarea name="message" rows="15" cols="40"></textarea><br />
    <input type="submit" value="send mail">
</form>
</body>
</html>