<form action="" method="post">
    <textarea name="message" rows="15" cols="40"></textarea><br />
    <input type="submit" value="send mail">
</form>