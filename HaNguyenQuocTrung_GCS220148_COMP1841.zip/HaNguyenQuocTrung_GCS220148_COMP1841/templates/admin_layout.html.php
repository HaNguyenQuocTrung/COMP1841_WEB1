<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?= $title ?></title>
    <link rel="stylesheet" href="../posts.css">
</head>

<body>
    <header id="admin">
        <h1>Greenwich Trung hahaha Admin Area<br />
            Manage Questions, Modulen, and Users
        </h1>
    </header>
    <nav>
        <ul>
            <li><a href="posts.php">Manage Questions</a></li>
            <!-- <li><a href="addpost.php">Manage modulen</a></li> -->
            <li><a href="manage.php">Manage Users</a></li>
            <li><a href="modulen.php">Manage Modulen</a></li>
            <li><a href="login/Logout.php">Public Site/Logout</a></li>
            <li><a href="message.php">Feedback</a></li>
        </ul>
    </nav>
    <main>
        <?= $output ?>
    </main>
    <footer>&copy; IJDB 2023</footer>
</body>

</html>